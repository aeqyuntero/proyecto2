 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TiposUsuarios;

import java.util.ArrayList;
/**
 *
 * @author estudiantes
 */
public class Usuario {
    
    private String nombre;
    private String apellido;
    private String username;
    private String pass;
    private String email;
    
    public Usuario (){
        
        this.nombre="";
        this.apellido="";
        this.username="";
        this.pass="";
        this.email="";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
}

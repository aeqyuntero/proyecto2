
create database proyecto;
use proyecto;

CREATE TABLE `puntajes` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `puntaje` int(10) NOT NULL,
  `juego` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `juego` (
  `id` int(11) NOT NULL,
  `nombreJuego` varchar(100) NOT NULL,
  `URL` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `usuario`, `email`, `pass`) VALUES
(1, 'Magic', 'Fractales', 'donchris', 'zabalakawaii@gmail.com', 'zabalachanesmipasion');
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contenido;

/**
 *
 * @author estudiantes
 */
public class Juego {
    
    private String nomJuego;
    private String URLMiniatura;
    private String URLJuego;
    private int vecesJugadas;
    
    public Juego(){
        this.nomJuego = "";
        this.URLMiniatura = "";
        this.URLJuego = "";
        this.vecesJugadas = 0;
    }

    public String getNomJuego() {
        return nomJuego;
    }

    public void setNomJuego(String nomJuego) {
        this.nomJuego = nomJuego;
    }

    public String getURLMiniatura() {
        return URLMiniatura;
    }

    public void setURLMiniatura(String URLMiniatura) {
        this.URLMiniatura = URLMiniatura;
    }

    public String getURLJuego() {
        return URLJuego;
    }

    public void setURLJuego(String URLJuego) {
        this.URLJuego = URLJuego;
    }

    public int getVecesJugadas() {
        return vecesJugadas;
    }

    public void setVecesJugadas(int vecesJugadas) {
        this.vecesJugadas = vecesJugadas;
    }
    
}

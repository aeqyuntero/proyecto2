/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TiposUsuarios;

/**
 *
 * @author estudiantes
 */
public class Admin {
    private final String AdminName="Admin";
    private final String Password="frivpropio";

    public String getAdminName() {
        return AdminName;
    }

    public String getPassword() {
        return Password;
    }
    
    public boolean validar_admin(String pass,String user){
        if(this.Password.equals(pass) && this.AdminName.equals(user)){
            return true;
        }else{
            return false;
        }
    }
}

//launcher
window.requestAnimationFrame(function(){
    new AdministradorJuego(4,EntradaDeTeclado,ManejoDOM);
});
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import contenido.Juego;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author estudiantes
 */
public class dbJuegos {
    
    dbConexion db;
    
    public dbJuegos(){
        this.db=new dbConexion();
    }
    
    public void insertar_juego(Juego j){
        try{
            String sql="insert into juego(nombreJuego,"
                    + "URLMin,"
                    + "URLJuego,"
                    + "veces)"
                    + "values(?,?,?,?)";
            PreparedStatement pstm=db.getConexion().prepareStatement(sql);
            pstm.setString(1, j.getNomJuego());
            pstm.setString(2, j.getURLMiniatura());
            pstm.setString(3, j.getURLJuego());
            pstm.setInt(4, j.getVecesJugadas());
            
            pstm.executeUpdate();
        }catch(SQLException e){
            System.out.println(e);
        }
    }
    
    public void sumar_veces_jugadas(Juego j){
        try{
            String sql="select * from juego where nombreJuego = ?";
            PreparedStatement pstm=db.getConexion().prepareStatement(sql);
            pstm.setString(1, j.getNomJuego());
            ResultSet res=pstm.executeQuery();
            if (res.next()){
                int suma = res.getInt("veces") + j.getVecesJugadas();
                sql="update alumnos set veces = ? where nombreJuego = ?";
                pstm=db.getConexion().prepareStatement(sql);
                pstm.setInt(1, suma);
                pstm.setString(2, j.getNomJuego());
                pstm.executeUpdate();
            }
        }catch(SQLException e){
            System.out.println(e);
        }
    }
    
    public ResultSet obtener_juego() throws SQLException{
        String sql="select * from juego";
        PreparedStatement pstm=db.getConexion().prepareStatement(sql);
        ResultSet res=pstm.executeQuery();
        return res;
    }
    
}
